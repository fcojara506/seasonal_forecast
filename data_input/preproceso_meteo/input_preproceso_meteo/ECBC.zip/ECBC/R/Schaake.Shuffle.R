

Schaake.Shuffle = function(refseries, seriestoshuffle){
  ###   Temporal structure reconstruction of Mod to get the same temporal structure as Ref
  ### => returns a shuffled vector mod such that "rank(mod) == rank(ref)"
  ### corresponds to the "Schaake Shuffle definition" from Clark et al. (2004) J of Hydrometeor. paper.

  ### FOR THE MOMENT: ref and mod must have the exact same length

  Rmod = rank(seriestoshuffle, ties.method="first")
  Rref = rank(refseries, ties.method="first")

  TF.mod.ref = Trans.funct(Rmod, Rref)

  Rmr.m = TF.mod.ref[Rmod]

  sorted.mod  = sort(seriestoshuffle)
  SS.mod = sorted.mod[Rmr.m]

  return(SS.mod)

}


