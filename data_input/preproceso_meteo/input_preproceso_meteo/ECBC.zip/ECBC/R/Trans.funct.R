# Transfert Function for RANK ORDERING

Trans.funct = function(rankX, rankY){

  if(length(rankX)!=length(rankY)){
    stop("length(ranK)!=length(rankY) in Trans.funct\n")
  }

  TF = array(NaN, dim=(length(rankX)))

  for(i in 1:(length(rankX))){
    TF[rankX[i]] = rankY[i]
  }

  return(TF)

}
