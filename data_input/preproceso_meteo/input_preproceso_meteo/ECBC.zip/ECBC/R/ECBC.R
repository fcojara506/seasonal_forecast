

ECBC = function(refseries, modref, modproj, raintype=FALSE, th=0, ...){

  if(raintype==FALSE){
    ## Univariate bias correstion through CDF-t
    C = CDFt(refseries, modref, modproj,...)
    BCseries = C$DS
  }
  else{ # raintype==TRUE
    THR_mod = Get.threshold(refseries, th, modref)
    POS_refseries = refseries[which(refseries>th)]
    POS_MODcal = modref[which(modref>THR_mod)]
    POS_MODproj = modproj[which(modproj>THR_mod)]

    C = CDFt(POS_refseries, POS_MODcal, POS_MODproj,...)
    BCseries = array(th,dim=length(modproj))
    BCseries[which(modproj>THR_mod)] = pmax((th+1e-6), C$DS)
  }

  ## Reconstruct temporal structure with Schaake shuffle on 1d-BC series
  ecbcResults = Schaake.Shuffle(refseries, BCseries)

  return(ecbcResults)

}

