Get.threshold = function(Obs, thr_obs, Mod){

### Get thr_mod st P(Obs<thr_obs) == P(Mod<thr_mod)

  p = (ecdf(Obs))(thr_obs)
  thr_mod = quantile(Mod,probs=p)

  return(thr_mod)

}

