rm(list = ls())

all_data = read.csv(file = "all_predictor_1981_2019_45cuencas.csv")
cod_cuencas = unique(all_data$catchment_code)

all_data$var = factor(all_data$var, levels=c("STORAGE","NINO1.2","ONI","PDO","SOI"))

library(shiny)
library(ggplot2)
library(shinyWidgets)
#library(shinythemes) # Add this line to load the shinythemes package

# Define UI for Shiny app
ui <- fluidPage(
  headerPanel("Exploración de predictores por cuencas"),
  sidebarLayout(
    sidebarPanel(
      sliderTextInput("catchment_code",
                      "Código de cuenca:",
                      choices = unique(cod_cuencas),
                      selected = sample(cod_cuencas, 1)
      ),
      sliderInput("target_wy",
                  "Año objetivo:",
                  min = min(unique(all_data$wy)),
                  max = max(unique(all_data$wy)),
                  step = 1,
                  value = sample(unique(all_data$wy), 1)
      )
    ),
    mainPanel(
      plotOutput("predictores_plot")
    )
  )
)

server <- function(input, output) {
  output$predictores_plot <- renderPlot({
    #subset the data based on user inputs
    data_input <- subset(all_data, catchment_code == input$catchment_code)
    target_wy <- input$target_wy
    
    #create the plot
    ggplot(data = data_input) +
      #add historical records
      geom_line(aes(x = month_wy, y = predictor_value, col = "1981-2020", group = wy)) +
      scale_x_discrete(expand = c(0, 0)) +
      #add median
      geom_line(aes(x = month_wy, y = median, col = "median", group = "wy")) +
      #add a target year
      geom_line(data = subset(data_input, wy == target_wy),
                aes(x = month_wy, y = predictor_value, col = "target_wy", group = "wy")) +
      scale_color_manual(values = c("median" = "red",
                                    "1981-2020" = "grey50",
                                    "target_wy" = "blue"),
                         labels=c('1981-2019','Mediana', target_wy)) +
      facet_wrap(var ~ ., scales = "free_y", ncol = 1) +
      labs(
        title = unique(data_input$gauge_name),
        x = "fecha de emisión",
        y = "valor del predictor",
        col = "Años hidrológicos"
      )
    
  }, height = 700, width = 600)
}

# Run the Shiny app
shinyApp(ui = ui, server = server,options = list(display.mode = 'showcase'))
